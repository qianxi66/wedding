#include <stdio.h>

int
main(void)
{
	printf("hello, world\n");
	return 0;
}
