#include "vstring.h"

void vstring(const GoString *src, long *p, JsonState *ret, uint64_t flags) {
    return vstring_1(src, p, ret, flags);
}
