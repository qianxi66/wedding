package cpuid

//go:generate go run private-gen.go
//go:generate gofmt -w ./private
