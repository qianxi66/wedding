# Contribution Guidelines

## Quality Standard

To ensure the continued stability of this package, tests are required that cover the change in order for a pull request to be merged.

## Reporting issues

Please open an issue or join the gitter chat [![Join the chat at https://gitter.im/go-playground/validator](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/go-playground/validator?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge) for any issues, questions or possible enhancements to the package.
